package qualifiers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * Created by Jeka on 03/10/2015.
 */
@Service
@EnableScheduling
public class LohicaServiceImpl implements LohicaService {
    @Autowired
    @Mongo
    private Dao dao;

    @Override
    @Scheduled(cron = "1/1 * * * * ?")
    public void doWork() throws InterruptedException {
        System.out.println("Working...");
        dao.save();
    }
}
