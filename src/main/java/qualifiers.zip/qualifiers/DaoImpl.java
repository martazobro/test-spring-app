package qualifiers;

import org.springframework.stereotype.Repository;

/**
 * Created by Jeka on 03/10/2015.
 */
@Mongo
public class DaoImpl implements Dao {
    @Override
    public void save() {
        System.out.println("Saving to Mongo.....");
    }
}
