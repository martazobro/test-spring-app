package neveruseswitch;

/**
 * Created by Jeka on 03/10/2015.
 */
public interface MailGenerator {
    String generateHtml();
}
