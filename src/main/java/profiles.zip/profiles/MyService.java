package profiles;

/**
 * Created by Jeka on 03/10/2015.
 */
public interface MyService {
    void doWork();
}
