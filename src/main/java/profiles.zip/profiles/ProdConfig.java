package profiles;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;

/**
 * Created by Jeka on 03/10/2015.
 */
@Configuration
@PropertySource("classpath:prod.properties")
@Profile("prod")
public class ProdConfig {

}
