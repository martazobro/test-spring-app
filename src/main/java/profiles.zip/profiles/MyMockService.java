package profiles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * Created by Jeka on 03/10/2015.
 */
@Service
@Profile("dev")
public class MyMockService implements MyService {

    @Autowired
    private EmployeeDao employeeDao;

    @Override
    public void doWork() {
        System.out.println(employeeDao.getPerson()+" was fired");
    }
}



